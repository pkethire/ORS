-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 08, 2018 at 01:06 PM
-- Server version: 5.1.36
-- PHP Version: 5.3.0

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `root`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `aname` varchar(21) NOT NULL,
  `apass` varchar(12) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`aname`, `apass`) VALUES
('admin', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `apply`
--

CREATE TABLE IF NOT EXISTS `apply` (
  `aname` varchar(10) NOT NULL,
  `aquali` varchar(50) NOT NULL,
  `percen` varchar(50) NOT NULL,
  `job` varchar(50) NOT NULL,
  `Filepath` varchar(55) NOT NULL,
  `resume` varchar(200) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(90) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `apply`
--

INSERT INTO `apply` (`aname`, `aquali`, `percen`, `job`, `Filepath`, `resume`, `date`, `status`) VALUES
('telu', 'select qualification', '', '', 'pending', 'pending', '2017-09-20', 'you are selected further details will be send to your mail'),
('akhil', 'Btech', '56', 'TCS', './uploadedFiles/1.title page.doc', '1.title page.doc', '2017-09-20', 'accepted'),
('student', 'Btech', '75', 'android develeper', 'pending', 'pending', '2018-05-06', 'accepted'),
('anu', 'Btech', '77', 'developer', 'pending', 'pending', '2018-05-06', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `job`
--

CREATE TABLE IF NOT EXISTS `job` (
  `jid` varchar(20) NOT NULL,
  `job` varchar(20) NOT NULL,
  `place` varchar(20) NOT NULL,
  `Experience` varchar(12) NOT NULL,
  `salary` varchar(100) NOT NULL,
  `lastdate` date NOT NULL,
  PRIMARY KEY (`jid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `job`
--

INSERT INTO `job` (`jid`, `job`, `place`, `Experience`, `salary`, `lastdate`) VALUES
('11', 'android develeper', 'hyderbad', '0', '11k', '2018-06-04'),
('122', 'Developer', 'hyderbad', '1', '23k', '2017-09-27');

-- --------------------------------------------------------

--
-- Table structure for table `pjob`
--

CREATE TABLE IF NOT EXISTS `pjob` (
  `jname` varchar(21) NOT NULL,
  `company` varchar(21) NOT NULL,
  `place` varchar(21) NOT NULL,
  `experience` int(12) NOT NULL,
  `salary` varchar(21) NOT NULL,
  `quali` varchar(21) NOT NULL,
  `speci` varchar(21) NOT NULL,
  `ladtdate` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pjob`
--

INSERT INTO `pjob` (`jname`, `company`, `place`, `experience`, `salary`, `quali`, `speci`, `ladtdate`) VALUES
('android developer', 'tata consultancy', 'hyderbad', 1, '11k', 'Btech', 'null', '21/05/2018');

-- --------------------------------------------------------

--
-- Table structure for table `provider`
--

CREATE TABLE IF NOT EXISTS `provider` (
  `pname` varchar(10) NOT NULL,
  `pass` varchar(10) NOT NULL,
  `email` varchar(20) NOT NULL,
  `company` varchar(20) NOT NULL,
  `contact` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `provider`
--

INSERT INTO `provider` (`pname`, `pass`, `email`, `company`, `contact`) VALUES
('hre', 'hre', 'hre@gmail.com', 'tata consultancy', '9989999112'),
('akhil', 'akhil', 'akhilkumar@gmail.com', 'TCS', '9098883322');

-- --------------------------------------------------------

--
-- Table structure for table `quaries`
--

CREATE TABLE IF NOT EXISTS `quaries` (
  `sname` varchar(10) NOT NULL,
  `quary` varchar(10000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quaries`
--

INSERT INTO `quaries` (`sname`, `quary`) VALUES
('telu', 'null'),
('student', 'null'),
('akhil', 'null');

-- --------------------------------------------------------

--
-- Table structure for table `reply`
--

CREATE TABLE IF NOT EXISTS `reply` (
  `sname` varchar(21) NOT NULL,
  `reply` varchar(10000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reply`
--

INSERT INTO `reply` (`sname`, `reply`) VALUES
('student', 'package for freshaers is11k'),
('telu', 'adasdasdasd'),
('akhil', 'soory for that we too dont know about that'),
('student', 'package for freshers will be 11k'),
('akhil', 'ascasc');

-- --------------------------------------------------------

--
-- Table structure for table `responce`
--

CREATE TABLE IF NOT EXISTS `responce` (
  `name` varchar(20) NOT NULL,
  `status` varchar(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `responce`
--


-- --------------------------------------------------------

--
-- Table structure for table `sregister`
--

CREATE TABLE IF NOT EXISTS `sregister` (
  `sname` varchar(10) NOT NULL,
  `pass` varchar(15) NOT NULL,
  `email` varchar(200) NOT NULL,
  `quali` varchar(50) NOT NULL,
  `Specilization` varchar(23) NOT NULL,
  `dob` varchar(20) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `Experience` varchar(54) NOT NULL,
  `Contact` varchar(23) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sregister`
--

INSERT INTO `sregister` (`sname`, `pass`, `email`, `quali`, `Specilization`, `dob`, `gender`, `Experience`, `Contact`) VALUES
('akhil', 'akhil', 'akhil@gmil.com', 'Btech', 'cse', '24//4//1998', 'male', '2', '1232313'),
('sandeep', 'sandeep', 'sandeepas', 'asda', '', '', '', '', ''),
('telu', 'telu', 'telu@gmail', 'Btech', 'CSE', '24//4//1996', 'male', '0', '9090909090'),
('vittu', 'vittu', 'email@email', 'Btech', 'CSE', '24//4//1996', 'male', '0', '9039039033'),
('mukesh', 'pass', 'mukes@as', 'Btech', 'CSE', '2//3//1971', 'male', '13', '1233444'),
('sandy', 'sandy', 'mukeshkota6@gmail.com', 'Btech', 'CSE', '17//11//1988', 'male', '16', '1234567890'),
('anu', 'anu', 'anu@gmail', 'Btech', 'CSE', '31//8//1998', 'female', '0', '700333333'),
('zaa', 'zaa', 'zaa@zaa', 'Btech', 'CSE', '2//2//1977', 'male', '0', '9099012321'),
('arjun', 'arjun', 'arjunkumar2@gmail.com', 'Bsc', 'CSE', '31//3//1996', 'male', '1', '8989898967'),
('student', 'student', 'teluakhilkumar@gmail.com', 'Btech', 'CSE', '1//1//1995', 'male', '0', '9899349993');
